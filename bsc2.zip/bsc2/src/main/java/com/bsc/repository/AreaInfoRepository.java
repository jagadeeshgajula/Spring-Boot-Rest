package com.bsc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bsc.model.AreaInfo;


public interface AreaInfoRepository extends JpaRepository<AreaInfo, Long> 
{

}
