package com.bsc.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bsc.model.AreaInfo;
import com.bsc.repository.AreaInfoRepository;

public class AreaInfoDAO {

	@Autowired
	AreaInfoRepository areaInfoRepository;
	
	 //save Area_Info 
	
	public AreaInfo save(AreaInfo info)
	{
		return areaInfoRepository.save(info);
	}
	
	 //find all areas 
	public List<AreaInfo> findAll()
	{
		return areaInfoRepository.findAll();
	}
	
	// find area by Zipcode 
	public AreaInfo findByZipcode(Long zipcode)
	{
		return areaInfoRepository.getOne(zipcode);
	}
}
