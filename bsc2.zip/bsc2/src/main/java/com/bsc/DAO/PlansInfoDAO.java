package com.bsc.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bsc.model.PlansInfo;
import com.bsc.repository.PlansRepository;

public class PlansInfoDAO {
	
	@Autowired
	PlansRepository plansRepository;
	
	 /*save Plan*/
	public PlansInfo save(PlansInfo plan)
	{
		return plansRepository.save(plan);
	}
	
	 /*get all plans */
	
	public List<PlansInfo> findAll()
	{
		return plansRepository.findAll();
	}
}
