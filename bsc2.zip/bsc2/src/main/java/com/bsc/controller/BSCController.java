package com.bsc.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bsc.DAO.AreaInfoDAO;
import com.bsc.DAO.PlansInfoDAO;
import com.bsc.model.AreaInfo;
import com.bsc.model.PlansInfo;

@RestController
@RequestMapping("/bsc")
public class BSCController {

	@Autowired
	AreaInfoDAO areaInfoDAO;
	
	@Autowired
	PlansInfoDAO plansInfoDAO;
	
	@GetMapping("/test")
	public String testing()
	{
		return "{hello}";
	}
	/* save an Area*/
	@PostMapping("/area")
	public AreaInfo createArea(@Valid @RequestBody AreaInfo area)
	{
		return areaInfoDAO.save(area);
	}
	
	/* get Area by Zipcode */
	@GetMapping("/area/{zipcode}")
	public ResponseEntity<Boolean> getAreaByZipcode(@PathVariable(value="zipcode") Long zipcode)
	{
		AreaInfo area = areaInfoDAO.findByZipcode(zipcode);
		
		if(area == null)
		{
			return ResponseEntity.notFound().build();
		}
		
		return ResponseEntity.ok().body(true);
	}
	
	/* save a plan */
	@PostMapping("/plan")
	public PlansInfo createPlan(@Valid @RequestBody PlansInfo plan)
	{
		return plansInfoDAO.save(plan);
	}
	
	/* get All Plans */
	@GetMapping("/plan")
	public List<PlansInfo> getAllPlans()
	{
		return plansInfoDAO.findAll();
	}
	
}
