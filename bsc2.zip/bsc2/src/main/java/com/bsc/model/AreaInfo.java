package com.bsc.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="area_Info")
@EntityListeners(AuditingEntityListener.class)
public class AreaInfo {
	
	@Id
	private long zipId;
	
	
	@NotBlank
	private String areaName;

	public long getZipId() {
		return zipId;
	}

	public void setZipId(long zipId) {
		this.zipId = zipId;
	}

	public String getArea_Name() {
		return areaName;
	}

	public void setArea_Name(String area_Name) {
		this.areaName = area_Name;
	}
}
