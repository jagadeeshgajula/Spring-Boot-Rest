package com.bsc.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="plans_Info")
@EntityListeners(AuditingEntityListener.class)
public class PlansInfo {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long plan_Id;
	
	@NotBlank
	private String plan_Name;
	
	@NotBlank
	private double plan_premium;

	public long getPlan_Id() {
		return plan_Id;
	}

	public void setPlan_Id(long plan_Id) {
		this.plan_Id = plan_Id;
	}

	public String getPlan_Name() {
		return plan_Name;
	}

	public void setPlan_Name(String plan_Name) {
		this.plan_Name = plan_Name;
	}

	public double getPlan_premium() {
		return plan_premium;
	}

	public void setPlan_premium(double plan_premium) {
		this.plan_premium = plan_premium;
	}
}
