package com.bsc.springbootexample.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bsc.springbootexample.DAO.AreaInfoDAO;
import com.bsc.springbootexample.DAO.PlansInfoDAO;
import com.bsc.springbootexample.model.AreaInfo;
import com.bsc.springbootexample.model.PlansInfo;

@CrossOrigin(origins = "http://localhost:8089")
@RestController
@RequestMapping(value="/bsc")
public class BSCController {

	@Autowired
	AreaInfoDAO areaInfoDAO;
	
	@Autowired
	PlansInfoDAO plansInfoDAO;
	
	@GetMapping("/test")
	public String testing()
	{
		return "{hello}";
	}
	/* save an Area*/
	@PostMapping("/area")
	public AreaInfo createArea(@Valid @RequestBody AreaInfo area)
	{
		return areaInfoDAO.save(area);
	}
	
	/* get Area by Zipcode */
	@GetMapping("/area/{zipId}")
	public ResponseEntity<Boolean> getAreaByZipcode(@PathVariable(value="zipId") Long zipId)
	{
		AreaInfo area = areaInfoDAO.findByZipcode(zipId);
		
		if(area == null)
		{
			return ResponseEntity.notFound().build();
		}
		
		return ResponseEntity.ok().body(true);
	}
	
	/* save a plan */
	@PostMapping("/plan")
	public PlansInfo createPlan(@Valid @RequestBody PlansInfo plan)
	{
		return plansInfoDAO.save(plan);
	}
	
	/* get All Plans */
	@GetMapping("/plan")
	public List<PlansInfo> getAllPlans()
	{
		return plansInfoDAO.findAll();
	}
	
}
