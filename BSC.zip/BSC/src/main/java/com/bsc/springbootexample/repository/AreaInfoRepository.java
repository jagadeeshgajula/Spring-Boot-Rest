package com.bsc.springbootexample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bsc.springbootexample.model.AreaInfo;


public interface AreaInfoRepository extends JpaRepository<AreaInfo, Long> 
{

}
