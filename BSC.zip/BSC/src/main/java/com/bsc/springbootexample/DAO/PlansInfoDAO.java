package com.bsc.springbootexample.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsc.springbootexample.model.PlansInfo;
import com.bsc.springbootexample.repository.PlansRepository;
@Service
public class PlansInfoDAO {
	
	@Autowired
	PlansRepository plansRepository;
	
	 /*save Plan*/
	public PlansInfo save(PlansInfo plan)
	{
		return plansRepository.save(plan);
	}
	
	 /*get all plans */
	
	public List<PlansInfo> findAll()
	{
		return plansRepository.findAll();
	}
}
