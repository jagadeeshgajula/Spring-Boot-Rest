package com.bsc.springbootexample.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="area_Info")
@EntityListeners(AuditingEntityListener.class)
public class AreaInfo {
	
	@Id
	private long zipId;
	
	
	private String Name;

	public long getZipId() {
		return zipId;
	}

	public void setZipId(long zipId) {
		this.zipId = zipId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}
}
