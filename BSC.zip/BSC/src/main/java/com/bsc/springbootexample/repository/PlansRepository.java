package com.bsc.springbootexample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bsc.springbootexample.model.PlansInfo;

public interface PlansRepository extends JpaRepository<PlansInfo, Long> 
{

}
