package com.bsc.springbootexample.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="plans_Info")
@EntityListeners(AuditingEntityListener.class)
public class PlansInfo {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long plan_Id;
	
	@NotBlank
	private String plan_Name;
	
	
	private Long premium;

	public long getPlan_Id() {
		return plan_Id;
	}

	public void setPlan_Id(long plan_Id) {
		this.plan_Id = plan_Id;
	}

	public String getPlan_Name() {
		return plan_Name;
	}

	public void setPlan_Name(String plan_Name) {
		this.plan_Name = plan_Name;
	}

	public Long getPremium() {
		return premium;
	}

	public void setPremium(Long premium) {
		this.premium = premium;
	}

	
}
