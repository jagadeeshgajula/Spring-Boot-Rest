package com.bsc.springbootexample.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsc.springbootexample.model.AreaInfo;
import com.bsc.springbootexample.repository.AreaInfoRepository;

@Service
public class AreaInfoDAO {

	@Autowired
	AreaInfoRepository areaInfoRepository;
	
	 //save Area_Info 
	
	public AreaInfo save(AreaInfo info)
	{
		return areaInfoRepository.save(info);
	}
	
	 //find all areas 
	public List<AreaInfo> findAll()
	{
		return areaInfoRepository.findAll();
	}
	
	// find area by Zipcode 
	public AreaInfo findByZipcode(Long zipcode)
	{
		return areaInfoRepository.findOne(zipcode);
	}
}
